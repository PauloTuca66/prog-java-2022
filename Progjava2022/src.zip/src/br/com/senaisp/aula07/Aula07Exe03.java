package br.com.senaisp.aula07;

public class Aula07Exe03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*
		 * Desenvolver um aplicativo para mostrar os 100 primeiros n�meros pares 
		 */
			System.out.println("Mostrar os 100 primeiro valores pares");
			for (int intValor = 2; intValor <= 200; intValor+= 2)
					System.out.println("" + intValor);
	}
}
