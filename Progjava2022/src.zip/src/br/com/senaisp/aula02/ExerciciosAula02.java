package br.com.senaisp.aula02;

public class ExerciciosAula02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//Primeira Express�o
		double dblConta= 2.00 / 5.00;
		System.out.println("Resultado da primeira expres�o �: " + dblConta);
		
		//Segunda Express�o
		dblConta= 2.00 / 3.00 + 10;
		System.out.println("Resultado da segunda expres�o �: " + dblConta);

		//Terceira Express�o
		dblConta= 1.00 / 5.00 * 3.00 / 4.00 + 5;
		System.out.println("Resultado da terceira expres�o �: " + dblConta);
		
		
	}

}
